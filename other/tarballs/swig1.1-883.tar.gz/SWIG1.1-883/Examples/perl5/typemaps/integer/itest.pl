# Test out our integer functions
# Each function call should now print out the argument values

use itest;
package itest;
print sumint(4,5),"\n";
print sumshort(23000,13456),"\n";
print sumlong(1999233,-78000000),"\n";
print sumuchar(79,153),"\n";

