use output;
package output;

print add(3,4.5),"\n";
print mul(0.1,79),"\n";
print neg(9),"\n";

($a,$b) = factor(32);
print "$a,$b\n";

