# Test some out some of our math functions

from example import *

print exp(-2.5);
print log(2)
print inv(0.25)
print sqrt(0)

# Now generate an exception

print "This will generate an error."

print log(0)

