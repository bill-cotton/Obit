import spam
print "Executing spam.system('ls') ... "
spam.system("ls")
