from output import *
print add(4,7)
print sub(4,7)
print mul(4,7)
print fdiv(4,7)
print neg(4)
