
struct foo {
  int a;
  int *b;
};

