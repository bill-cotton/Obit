
/* SWIG version information */

#define SWIG_MAJOR_VERSION 1
#define SWIG_MINOR_VERSION 1
#define SWIG_SPIN "(Build 883)"
