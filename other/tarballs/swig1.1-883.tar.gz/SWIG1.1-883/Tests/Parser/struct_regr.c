/* DEBUG : Language specific headers go here */

/* DEBUG : Pointer conversion function here */

/* DEBUG : Language specific code here */

#define   SWIG_init     swig_init

#define   SWIG_name    "swig"
C++ CLASS DECLARATION : struct Struct
C++ CLASS DECLARATION : union Value
C++ CLASS DECLARATION : class Object
C++ CLASS DECLARATION : struct Struct1
C++ CLASS DECLARATION : union Value1
C++ CLASS DECLARATION : class Object1
C++ CLASS DECLARATION : struct Struct2
C++ CLASS DECLARATION : union Value2
C++ CLASS DECLARATION : class Object2
C++ CLASS DECLARATION : struct Struct3
C++ CLASS DECLARATION : union Value3
C++ CLASS DECLARATION : class Object3
C++ CLASS DECLARATION : struct Struct4
C++ CLASS DECLARATION : union Value4
C++ CLASS DECLARATION : class Object4
C++ CLASS DECLARATION : struct Struct5
C++ CLASS DECLARATION : union Value5
C++ CLASS DECLARATION : class Object5
C++ CLASS START : struct Struct  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : union Value  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : class Object  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
        MEMBER FUNC   : double foo();

        CONSTRUCTOR   : Object *Object();
        DESTRUCTOR    : ~Object();
C++ CLASS END ===================================================

C++ CLASS START : struct Struct1  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : union Value1  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : class Object1  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
        MEMBER FUNC   : double foo();

        CONSTRUCTOR   : Object1 *Object1();
        DESTRUCTOR    : ~Object1();
C++ CLASS END ===================================================

C++ CLASS START : struct Struct2  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : union Value2  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : class Object2  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
        MEMBER FUNC   : double foo();

        CONSTRUCTOR   : Object2 *Object2();
        DESTRUCTOR    : ~Object2();
C++ CLASS END ===================================================

C++ CLASS START : struct Struct3  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : union Value3  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : class Object3  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
        MEMBER FUNC   : double foo();

        CONSTRUCTOR   : Object3 *Object3();
        DESTRUCTOR    : ~Object3();
C++ CLASS END ===================================================

C++ CLASS START : struct Struct4  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : union Value4  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : class Object4  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
        MEMBER FUNC   : double foo();

        CONSTRUCTOR   : Object4 *Object4();
        DESTRUCTOR    : ~Object4();
C++ CLASS END ===================================================

C++ CLASS START : struct Struct5  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : union Value5  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
C++ CLASS END ===================================================

C++ CLASS START : class Object5  ========================================

        ATTRIBUTE     : double  d; 
        ATTRIBUTE     : int  i; 
        ATTRIBUTE     : float  f; 
        ATTRIBUTE     : char * c; 
        MEMBER FUNC   : double foo();

        CONSTRUCTOR   : Object5 *Object5();
        DESTRUCTOR    : ~Object5();
C++ CLASS END ===================================================

SWIG POINTER-MAPPING TABLE

/*
 * This table is used by the pointer type-checker
 */
static struct { char *n1; char *n2; void *(*pcnv)(void *); } _swig_mapping[] = {
    { "_signed_long","_long",0},
    { "_Value1","_union_Value1",0},
    { "_Value3","_union_Value3",0},
    { "_Value4","_union_Value4",0},
    { "_class_Object","_Object",0},
    { "_Object1","_class_Object1",0},
    { "_long","_unsigned_long",0},
    { "_long","_signed_long",0},
    { "_Struct","_struct_Struct",0},
    { "_Object3","_class_Object3",0},
    { "_Object4","_class_Object4",0},
    { "_class_Object1","_Object1",0},
    { "_class_Object3","_Object3",0},
    { "_class_Object4","_Object4",0},
    { "_unsigned_long","_long",0},
    { "_union_Value","_Value",0},
    { "_signed_int","_int",0},
    { "_Struct1","_struct_Struct1",0},
    { "_unsigned_short","_short",0},
    { "_Struct3","_struct_Struct3",0},
    { "_Struct4","_struct_Struct4",0},
    { "_signed_short","_short",0},
    { "_unsigned_int","_int",0},
    { "_short","_unsigned_short",0},
    { "_short","_signed_short",0},
    { "_union_Value1","_Value1",0},
    { "_int","_unsigned_int",0},
    { "_int","_signed_int",0},
    { "_union_Value3","_Value3",0},
    { "_union_Value4","_Value4",0},
    { "_struct_Struct","_Struct",0},
    { "_struct_Struct1","_Struct1",0},
    { "_struct_Struct3","_Struct3",0},
    { "_struct_Struct4","_Struct4",0},
    { "_Value","_union_Value",0},
    { "_Object","_class_Object",0},
{0,0,0}};


/* MODULE INITIALIZATION */

void swig_init() {

     // C++ CLASS START : struct Struct
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : union Value
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : class Object
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     ADD MEMBER FUN : foo --> double foo();
     ADD CONSTRUCT  : Object --> Object *Object();
     ADD DESTRUCT  : Object --> ~Object();
     // C++ CLASS END 


     // C++ CLASS START : struct Struct1
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : union Value1
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : class Object1
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     ADD MEMBER FUN : foo --> double foo();
     ADD CONSTRUCT  : Object1 --> Object1 *Object1();
     ADD DESTRUCT  : Object1 --> ~Object1();
     // C++ CLASS END 


     // C++ CLASS START : struct Struct2
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : union Value2
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : class Object2
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     ADD MEMBER FUN : foo --> double foo();
     ADD CONSTRUCT  : Object2 --> Object2 *Object2();
     ADD DESTRUCT  : Object2 --> ~Object2();
     // C++ CLASS END 


     // C++ CLASS START : struct Struct3
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : union Value3
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : class Object3
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     ADD MEMBER FUN : foo --> double foo();
     ADD CONSTRUCT  : Object3 --> Object3 *Object3();
     ADD DESTRUCT  : Object3 --> ~Object3();
     // C++ CLASS END 


     // C++ CLASS START : struct Struct4
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : union Value4
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : class Object4
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     ADD MEMBER FUN : foo --> double foo();
     ADD CONSTRUCT  : Object4 --> Object4 *Object4();
     ADD DESTRUCT  : Object4 --> ~Object4();
     // C++ CLASS END 


     // C++ CLASS START : struct Struct5
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : union Value5
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     // C++ CLASS END 


     // C++ CLASS START : class Object5
     ADD MEMBER     : d --> double  d; 
     ADD MEMBER     : i --> int  i; 
     ADD MEMBER     : f --> float  f; 
     ADD MEMBER     : c --> char * c; 
     ADD MEMBER FUN : foo --> double foo();
     ADD CONSTRUCT  : Object5 --> Object5 *Object5();
     ADD DESTRUCT  : Object5 --> ~Object5();
     // C++ CLASS END 

}  /* END INIT */
{
   int i;
   for (i = 0; _swig_mapping[i].n1; i++)
        SWIG_RegisterMapping(_swig_mapping[i].n1,_swig_mapping[i].n2,_swig_mapping[i].pcnv);
}
