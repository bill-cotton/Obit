/*******************************************************************************
 * Simplified Wrapper and Interface Generator  (SWIG)
 * 
 * Author : David Beazley
 *
 * Department of Computer Science        
 * University of Chicago
 * 1100 E 58th Street
 * Chicago, IL  60637
 * beazley@cs.uchicago.edu
 *
 * Please read the file LICENSE for the copyright and terms by which SWIG
 * can be used and distributed.
 *******************************************************************************/
/***********************************************************************
 * $Header: /cvsroot/SWIG1.1/Modules/wrap.h,v 1.3 1999/08/17 03:31:31 beazley Exp $
 *
 * wrap.h
 ***********************************************************************/

#include "swig.h"

#ifndef SWIG_LIB
#define SWIG_LIB = "./swig_lib"
#endif

#ifndef SWIG_LANG
#define SWIG_LANG TCL
#endif

#ifndef SWIG_DOC
#define SWIG_DOC ASCII
#endif





